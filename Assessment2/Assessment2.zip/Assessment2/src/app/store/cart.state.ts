import { cartstore } from '../cart';
export interface cartState {
  product: cartstore[];
  count: number;
}
