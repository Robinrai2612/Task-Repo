import { cartState } from './store/cart.state';

export interface AppState {
  cart: cartState;
  //products: Array<Product>;
}


