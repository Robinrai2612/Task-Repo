export interface cartstore {
  id: number;
  title: string;
  price: number;
  quantity: number;
  //descrption: string;
  //image: string;
  //category: string;
}
